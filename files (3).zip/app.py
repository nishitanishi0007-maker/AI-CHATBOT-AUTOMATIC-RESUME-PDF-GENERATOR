"""
AI Resume Builder - Flask Backend
Powered by Anthropic Claude API
"""

from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
import anthropic
import json
import os
import re

app = Flask(__name__)
CORS(app)

# Initialize Anthropic client (reads ANTHROPIC_API_KEY from environment)
client = anthropic.Anthropic()
MODEL = "claude-opus-4-5"

# ──────────────────────────────────────────────
# Serve the frontend
# ──────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


# ──────────────────────────────────────────────
# 1. AI Chatbot  (floating popup + AI Assistant tab)
# ──────────────────────────────────────────────
@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "")
    history = data.get("history", [])          # [{role, content}, ...]
    resume_context = data.get("resume", {})    # current form data for context

    if not user_message:
        return jsonify({"error": "No message provided"}), 400

    system_prompt = f"""You are an expert AI Resume Assistant for a resume builder web app.
Your job is to help users write better resumes, suggest skills, craft career objectives,
improve ATS scores, and give career advice.

Current resume data (use this to personalise answers):
{json.dumps(resume_context, indent=2)}

Rules:
- Be concise, friendly, and actionable.
- When suggesting skills or objectives, tailor them to the user's profile.
- When filling fields, respond with a JSON block wrapped in <fill> tags like:
  <fill>{{"key": "objective", "value": "your text here"}}</fill>
  Valid keys: name, email, phone, address, linkedin, github, objective,
              skills (comma-separated), degree, institute, passout, role, company,
              project, tech, hobbies, languages
- Only include <fill> when the user explicitly asks to set/fill/add a field.
- Otherwise, just give helpful advice in plain text (you may use markdown formatting).
"""

    messages = history + [{"role": "user", "content": user_message}]

    try:
        response = client.messages.create(
            model=MODEL,
            max_tokens=1024,
            system=system_prompt,
            messages=messages,
        )
        reply = response.content[0].text
        return jsonify({"reply": reply})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ──────────────────────────────────────────────
# 2. Generate Career Objective
# ──────────────────────────────────────────────
@app.route("/api/objective", methods=["POST"])
def generate_objective():
    data = request.get_json()
    name = data.get("name", "the candidate")
    skills = data.get("skills", [])
    education = data.get("education", [])
    target_role = data.get("target_role", "")

    prompt = f"""Write a professional one-paragraph career objective (3-4 sentences) for a resume.

Candidate name: {name}
Skills: {', '.join(skills) if skills else 'various technologies'}
Education: {json.dumps(education) if education else 'Not specified'}
Target role: {target_role if target_role else 'Not specified'}

Output ONLY the objective paragraph, no preamble or labels."""

    try:
        response = client.messages.create(
            model=MODEL,
            max_tokens=300,
            messages=[{"role": "user", "content": prompt}],
        )
        objective = response.content[0].text.strip()
        return jsonify({"objective": objective})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ──────────────────────────────────────────────
# 3. ML Analysis / ATS Score  (real scoring)
# ──────────────────────────────────────────────
@app.route("/api/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    resume = data.get("resume", {})

    prompt = f"""You are a professional resume analyst and ATS scoring system.
Analyze this resume data and return a JSON object ONLY (no markdown, no preamble).

Resume data:
{json.dumps(resume, indent=2)}

Return exactly this JSON structure:
{{
  "ats_score": <integer 0-100>,
  "score_label": "<Needs Work | Fair | Good | Strong | Excellent>",
  "metrics": {{
    "accuracy": "<XX.X%>",
    "precision": "<XX.X%>",
    "recall": "<XX.X%>",
    "f1": "<XX.X%>"
  }},
  "models": {{
    "lr":  {{"a": "<XX.X%>", "p": "<XX.X%>", "r": "<XX.X%>", "f": "<XX.X%>"}},
    "rf":  {{"a": "<XX.X%>", "p": "<XX.X%>", "r": "<XX.X%>", "f": "<XX.X%>"}},
    "gb":  {{"a": "<XX.X%>", "p": "<XX.X%>", "r": "<XX.X%>", "f": "<XX.X%>"}},
    "svm": {{"a": "<XX.X%>", "p": "<XX.X%>", "r": "<XX.X%>", "f": "<XX.X%>"}}
  }},
  "sections": {{
    "Personal": <0-100>,
    "Objective": <0-100>,
    "Skills": <0-100>,
    "Education": <0-100>,
    "Internships": <0-100>,
    "Projects": <0-100>,
    "Certs": <0-100>,
    "Achievements": <0-100>
  }},
  "tips": ["tip1", "tip2", "tip3", "tip4", "tip5"]
}}

Base the scores on resume completeness, keyword richness, section balance, and ATS best practices.
Return ONLY the JSON, nothing else."""

    try:
        response = client.messages.create(
            model=MODEL,
            max_tokens=800,
            messages=[{"role": "user", "content": prompt}],
        )
        text = response.content[0].text.strip()
        # Strip possible markdown fences
        text = re.sub(r"^```[a-z]*\n?", "", text)
        text = re.sub(r"\n?```$", "", text)
        result = json.loads(text)
        return jsonify(result)

    except json.JSONDecodeError as e:
        return jsonify({"error": f"JSON parse error: {e}"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ──────────────────────────────────────────────
# 4. Suggest Skills
# ──────────────────────────────────────────────
@app.route("/api/suggest-skills", methods=["POST"])
def suggest_skills():
    data = request.get_json()
    role = data.get("role", "software engineer")
    existing = data.get("existing_skills", [])

    prompt = f"""Suggest 10 relevant technical skills for a {role} resume.
Existing skills to avoid duplicating: {', '.join(existing) if existing else 'none'}
Return ONLY a JSON array of skill strings, no preamble.
Example: ["Python", "TensorFlow", "SQL"]"""

    try:
        response = client.messages.create(
            model=MODEL,
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}],
        )
        text = response.content[0].text.strip()
        text = re.sub(r"^```[a-z]*\n?", "", text)
        text = re.sub(r"\n?```$", "", text)
        skills = json.loads(text)
        return jsonify({"skills": skills})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ──────────────────────────────────────────────
# 5. Improve a section's description
# ──────────────────────────────────────────────
@app.route("/api/improve", methods=["POST"])
def improve_text():
    data = request.get_json()
    section = data.get("section", "description")
    text = data.get("text", "")
    role = data.get("role", "")

    if not text:
        return jsonify({"error": "No text provided"}), 400

    prompt = f"""Improve the following resume {section} for a {role or 'tech'} role.
Make it more impactful: use strong action verbs, add quantified achievements where possible,
keep it concise (2-4 bullet points or sentences).

Original:
{text}

Return ONLY the improved text, no labels or preamble."""

    try:
        response = client.messages.create(
            model=MODEL,
            max_tokens=300,
            messages=[{"role": "user", "content": prompt}],
        )
        improved = response.content[0].text.strip()
        return jsonify({"improved": improved})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "false").lower() == "true"
    print(f"🚀 AI Resume Builder running on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=debug)
