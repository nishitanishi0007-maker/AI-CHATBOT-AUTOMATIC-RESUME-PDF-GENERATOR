"""
AI Assistant - Resume Builder Chatbot
Provides guided step-by-step resume building via conversational flow.
"""

import re
import random


OBJECTIVE_TEMPLATES = [
    "Motivated {field} professional with expertise in {skills}, seeking a challenging role at a forward-thinking organization to leverage my skills in delivering high-impact solutions and driving measurable outcomes.",
    "Results-driven {field} enthusiast with hands-on experience in {skills}. Looking to contribute technical expertise and problem-solving abilities to a growth-oriented team.",
    "Passionate {field} professional skilled in {skills}, with a strong foundation in delivering scalable solutions. Eager to bring analytical thinking and innovative approaches to a dynamic team.",
    "Detail-oriented {field} graduate with practical expertise in {skills}. Committed to continuous learning and delivering excellent results in a collaborative environment.",
]

CHAT_FLOWS = {
    "name":      "What's your full name?",
    "email":     "What's your email address?",
    "phone":     "What's your phone number?",
    "address":   "What's your city and state?",
    "linkedin":  "What's your LinkedIn profile URL? (or type 'skip')",
    "github":    "What's your GitHub/Portfolio URL? (or type 'skip')",
    "objective": "Tell me about your career goal in a sentence or two, and I'll polish it for you.",
    "skills":    "List your top technical skills, separated by commas.",
    "done":      "🎉 Great! Your resume is taking shape. Click 'Generate PDF' to download it!",
}

FOLLOW_UPS = {
    "improve": [
        "Try adding quantified achievements — e.g., 'Improved system performance by 40%'.",
        "Use strong action verbs like 'Architected', 'Optimized', 'Led' to begin bullet points.",
        "Tailor your skills section to match the job description for higher ATS scores.",
    ],
    "skills": [
        "Include both hard skills (Python, SQL) and soft skills (Leadership, Communication).",
        "Certifications count as skills too — add AWS, Google Cloud, or Coursera certs.",
    ],
    "general": [
        "Keep your resume to 1 page if you have less than 5 years of experience.",
        "Use consistent formatting — same fonts, spacing, and bullet styles throughout.",
        "Proofread! Typos are resume killers.",
    ]
}


class AIAssistant:

    def generate_objective(self, data: dict) -> str:
        """Generate a professional career objective from user data."""
        skills_list = data.get("technical_skills", [])
        if isinstance(skills_list, str):
            skills_list = [s.strip() for s in skills_list.split(",")]

        top_skills = ", ".join(skills_list[:3]) if skills_list else "technology and problem-solving"

        # Detect field from skills or objective
        field = self._detect_field(skills_list, data.get("career_objective", ""))

        template = random.choice(OBJECTIVE_TEMPLATES)
        return template.format(field=field, skills=top_skills)

    def chat(self, message: str, context: dict) -> str:
        """Handle AI assistant chat messages."""
        msg = message.lower().strip()

        # Greetings
        if any(w in msg for w in ["hi", "hello", "hey", "start"]):
            return "👋 Hi! I'm your AI Resume Assistant. Let's build an impressive resume together! What's your **full name**?"

        # Score / improve request
        if any(w in msg for w in ["score", "rate", "evaluate"]):
            return "To score your resume, fill out all the sections and click **'Score Resume'** in the ML Analytics tab. I'll analyze it using NLP and give you detailed feedback!"

        # Skill tips
        if "skill" in msg:
            return random.choice(FOLLOW_UPS["skills"])

        # Improvement tips
        if any(w in msg for w in ["improve", "better", "tips", "help"]):
            return random.choice(FOLLOW_UPS["improve"])

        # Objective help
        if "objective" in msg:
            return "Click **'AI Generate Objective'** below the Career Objective field and I'll craft a tailored objective based on your profile!"

        # PDF / download
        if any(w in msg for w in ["pdf", "download", "export"]):
            return "Once you've filled in all sections, scroll to the bottom and click **'Download PDF'** to get your formatted resume!"

        # Career advice
        if any(w in msg for w in ["career", "job", "role", "path"]):
            return "Head over to the **ML Analytics** tab → **Career Predictor** to get personalized career path predictions based on your skills!"

        # Default helpful response
        tips = FOLLOW_UPS["general"]
        return f"💡 Quick tip: {random.choice(tips)}\n\nFeel free to ask me about improving your resume, career paths, or skill recommendations!"

    # ── Private ──────────────────────────────────────────────────────────────

    def _detect_field(self, skills: list, objective: str) -> str:
        text = " ".join(skills).lower() + " " + objective.lower()
        if any(k in text for k in ["machine learning", "deep learning", "ai", "data science"]):
            return "AI/ML"
        if any(k in text for k in ["react", "vue", "frontend", "html", "css"]):
            return "Frontend Development"
        if any(k in text for k in ["docker", "kubernetes", "devops", "aws"]):
            return "DevOps"
        if any(k in text for k in ["security", "cybersecurity", "network"]):
            return "Cybersecurity"
        if any(k in text for k in ["data", "sql", "tableau", "analytics"]):
            return "Data Analytics"
        return "Software Engineering"
