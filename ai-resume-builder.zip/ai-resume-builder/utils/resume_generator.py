"""
Resume PDF Generator
Generates a professional PDF resume using ReportLab.
Falls back to plain text if ReportLab is not installed.
"""

import os
import tempfile

def generate_pdf_resume(data: dict) -> str:
    """Generate a PDF resume and return the file path."""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable, Table, TableStyle
        from reportlab.lib.enums import TA_LEFT, TA_CENTER

        return _generate_with_reportlab(data)
    except ImportError:
        return _generate_plain_text(data)


def _generate_with_reportlab(data: dict) -> str:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, HRFlowable
    from reportlab.lib.enums import TA_LEFT, TA_CENTER

    tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False)
    doc = SimpleDocTemplate(tmp.name, pagesize=A4,
                            leftMargin=18*mm, rightMargin=18*mm,
                            topMargin=15*mm, bottomMargin=15*mm)

    DARK   = colors.HexColor("#1a1a2e")
    ACCENT = colors.HexColor("#e94560")
    GRAY   = colors.HexColor("#555555")

    styles = getSampleStyleSheet()

    name_style = ParagraphStyle("Name", fontSize=22, textColor=DARK,
                                 fontName="Helvetica-Bold", alignment=TA_CENTER, spaceAfter=2)
    contact_style = ParagraphStyle("Contact", fontSize=9, textColor=GRAY,
                                    alignment=TA_CENTER, spaceAfter=6)
    section_style = ParagraphStyle("Section", fontSize=11, textColor=ACCENT,
                                    fontName="Helvetica-Bold", spaceBefore=10, spaceAfter=2)
    body_style = ParagraphStyle("Body", fontSize=9.5, textColor=DARK,
                                 leading=14, spaceAfter=4)
    bullet_style = ParagraphStyle("Bullet", fontSize=9.5, textColor=DARK,
                                   leading=14, leftIndent=12, spaceAfter=2)

    story = []

    # ── Header ──────────────────────────────────────────────────────────────
    name = data.get("name", "Your Name")
    story.append(Paragraph(name, name_style))

    contact_parts = []
    if data.get("phone"):    contact_parts.append(data["phone"])
    if data.get("email"):    contact_parts.append(data["email"])
    if data.get("address"):  contact_parts.append(data["address"])
    if data.get("linkedin"): contact_parts.append(data["linkedin"])
    if data.get("github"):   contact_parts.append(data["github"])
    story.append(Paragraph("  |  ".join(contact_parts), contact_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=ACCENT))
    story.append(Spacer(1, 4))

    # ── Objective ────────────────────────────────────────────────────────────
    if data.get("career_objective"):
        story.append(Paragraph("CAREER OBJECTIVE", section_style))
        story.append(HRFlowable(width="100%", thickness=0.5, color=GRAY))
        story.append(Spacer(1, 3))
        story.append(Paragraph(data["career_objective"], body_style))

    # ── Skills ───────────────────────────────────────────────────────────────
    skills = data.get("technical_skills", [])
    if skills:
        if isinstance(skills, str):
            skills = [s.strip() for s in skills.split(",")]
        story.append(Paragraph("TECHNICAL SKILLS", section_style))
        story.append(HRFlowable(width="100%", thickness=0.5, color=GRAY))
        story.append(Spacer(1, 3))
        story.append(Paragraph("  •  ".join(skills), body_style))

    # ── Experience ───────────────────────────────────────────────────────────
    experience = data.get("experience", [])
    if experience:
        story.append(Paragraph("WORK EXPERIENCE", section_style))
        story.append(HRFlowable(width="100%", thickness=0.5, color=GRAY))
        for exp in experience:
            if isinstance(exp, dict):
                story.append(Spacer(1, 4))
                title = exp.get("title", "")
                company = exp.get("company", "")
                duration = exp.get("duration", "")
                story.append(Paragraph(
                    f"<b>{title}</b> — {company} <font color='#888888'>({duration})</font>",
                    body_style
                ))
                desc = exp.get("description", "")
                if desc:
                    for line in desc.split("\n"):
                        if line.strip():
                            story.append(Paragraph(f"• {line.strip()}", bullet_style))

    # ── Education ────────────────────────────────────────────────────────────
    education = data.get("education", [])
    if education:
        story.append(Paragraph("EDUCATION", section_style))
        story.append(HRFlowable(width="100%", thickness=0.5, color=GRAY))
        for edu in education:
            if isinstance(edu, dict):
                story.append(Spacer(1, 4))
                degree = edu.get("degree", "")
                inst   = edu.get("institution", "")
                year   = edu.get("year", "")
                gpa    = edu.get("gpa", "")
                line   = f"<b>{degree}</b> — {inst}"
                if year: line += f" <font color='#888888'>({year})</font>"
                if gpa:  line += f"  |  GPA: {gpa}"
                story.append(Paragraph(line, body_style))

    doc.build(story)
    return tmp.name


def _generate_plain_text(data: dict) -> str:
    """Fallback: generate a .txt file if ReportLab is unavailable."""
    lines = [
        data.get("name", ""),
        data.get("email", "") + "  |  " + data.get("phone", ""),
        "",
        "CAREER OBJECTIVE",
        data.get("career_objective", ""),
        "",
        "SKILLS",
        ", ".join(data.get("technical_skills", [])),
    ]
    tmp = tempfile.NamedTemporaryFile(suffix=".txt", delete=False, mode="w")
    tmp.write("\n".join(lines))
    tmp.close()
    return tmp.name
